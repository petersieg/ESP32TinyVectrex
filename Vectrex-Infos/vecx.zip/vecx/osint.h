#ifndef __OSINT_H
#define __OSINT_H

extern char gbuffer[1024];

void osint_render (void);
int osint_msgs (void);

#endif
