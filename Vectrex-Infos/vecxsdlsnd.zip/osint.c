//
// This is a port of the vectrex emulator "vecx", by Valavan Manohararajah.
// Portions of this code copyright James Higgs 2005/2007.
// These portions are:
// 1. Ay38910 PSG (audio) emulation wave-buffering code.
// I, Peter Sieg used this sound emulation code from James Higgs in vecxsdl. 2007-12-06
//

#ifdef WIN32
#include <windows.h>
#endif

#include <stdlib.h>
#include <stdio.h>
#include <GL/gl.h>

#include "SDL/SDL.h"
#include "IL/il.h"
#include "IL/ilu.h"
#include "IL/ilut.h"
#include "osint.h"
#include "vecx.h"
#include "bios.h"
#include "wnoise.h"						// White noise waveform


#define EMU_TIMER					20
#define DEFAULT_XRES				330
#define DEFAULT_YRES				410
#define DEFAULT_LINEWIDTH			1
#define DEFAULT_OVERLAYTRANSPARENCY	0.5
#define DEFAULT_VECTORCOLOR_R		255
#define DEFAULT_VECTORCOLOR_G		255
#define DEFAULT_VECTORCOLOR_B		255

// AY38910 emulation stuff
extern unsigned snd_regs[16];
Uint8 AY_vol[3];
Uint16 AY_spufreq[3];
Uint16 AY_noisefreq;
Uint8 AY_tone_enable[3];
Uint8 AY_noise_enable[3];
static Uint8 AY_debug = 0;

// SDL audio stuff
SDL_AudioSpec reqSpec;
SDL_AudioSpec givenSpec;
SDL_AudioSpec *usedSpec;
Uint8 *pWave;



typedef struct {
	char *cartname;
	char *biosname;
	char *overlayname;
	int xres;
	int yres;
	float linewidth;
	float overlaytransparency;
	unsigned char vectorcolor[3];
}CommandLineArgs;


CommandLineArgs arguments;
int paused;


static void quit(int code) {
	ilShutDown();
	SDL_Quit();
	exit(code);
}


static void initopengl(const CommandLineArgs *args) {

	glClearColor(0,0,0,1);

	glViewport(0, 0, args->xres, args->yres);

	glLineWidth(args->linewidth);
	glPointSize(args->linewidth);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, ALG_MAX_X, ALG_MAX_Y, 0, -1, 1);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}


static void initsdl(const CommandLineArgs *args) {

	const SDL_VideoInfo* info = NULL;
	int bpp = 0;
	int flags = 0;

	if (SDL_Init(SDL_INIT_VIDEO) < 0 ) {
		fprintf(stderr, "Video initialization failed: %s\n", SDL_GetError());
		quit(1);
	}

	info = SDL_GetVideoInfo();
	if(!info) {
		fprintf(stderr, "Video query failed: %s\n", SDL_GetError());
		quit(1);
	}

	bpp = info->vfmt->BitsPerPixel;

	SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 5);
	SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 5);
	SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 5);
	SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 16);
	SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

	flags = SDL_OPENGL; // | SDL_FULLSCREEN;

	if (SDL_SetVideoMode(args->xres, args->yres, bpp, flags) == 0) {
		fprintf(stderr, "Video mode set failed: %s\n", SDL_GetError());
		quit(1);
	}

	initopengl(args);
}


static void handle_key_down(SDL_keysym* keysym) {

	switch (keysym->sym) {
		case SDLK_ESCAPE:
			quit(0);
			break;
		case SDLK_a:
			snd_regs[14] &= ~0x01;
			break;
		case SDLK_s:
			snd_regs[14] &= ~0x02;
			break;
		case SDLK_d:
			snd_regs[14] &= ~0x04;
			break;
		case SDLK_f:
			snd_regs[14] &= ~0x08;
			break;
		case SDLK_LEFT:
			alg_jch0 = 0x00;
			break;
		case SDLK_RIGHT:
			alg_jch0 = 0xff;
			break;
		case SDLK_UP:
			alg_jch1 = 0xff;
			break;
		case SDLK_DOWN:
			alg_jch1 = 0x00;
			break;
		default:
			break;
	}
}


static void handle_key_up(SDL_keysym* keysym) {

	switch (keysym->sym) {
		case SDLK_BACKSPACE:
			vecx_reset();
			break;
		case SDLK_LEFT:
			alg_jch0 = 0x80;
			break;
		case SDLK_a:
			snd_regs[14] |= 0x01;
			break;
		case SDLK_s:
			snd_regs[14] |= 0x02;
			break;
		case SDLK_d:
			snd_regs[14] |= 0x04;
			break;
		case SDLK_f:
			snd_regs[14] |= 0x08;
			break;
		case SDLK_p:
			paused = !paused;
			if (paused) {
				SDL_WM_SetCaption("vecxsdl - paused", NULL);
			} else {
				SDL_WM_SetCaption("vecxsdl", NULL);
			}
			break;
		case SDLK_RIGHT:
			alg_jch0 = 0x80;
			break;
		case SDLK_UP:
			alg_jch1 = 0x80;
			break;
		case SDLK_DOWN:
			alg_jch1 = 0x80;
			break;
		default:
			break;
	}
}


static void process_events(void) {

	SDL_Event event;

	while (SDL_PollEvent(&event)) {

		switch (event.type) {
			case SDL_KEYDOWN:
				handle_key_down(&event.key.keysym);
				break;
			case SDL_KEYUP:
				handle_key_up(&event.key.keysym);
				break;
			case SDL_QUIT:
				quit(0);
				break;
			default:
				break;
		}
	}
}


void osint_render(void) {

	long i;
	vector_t *vec;
	float ot;

	// draw overlay or clear screen if no overlay is used
	if (arguments.overlayname) {
		ot = arguments.overlaytransparency;
		glColor3f(ot, ot, ot);
		glEnable(GL_TEXTURE_2D);
		glBegin(GL_QUADS);
			glTexCoord2f(0.8f, 1);
			glVertex2f(ALG_MAX_X, 0);
			glTexCoord2f(0.2f, 1);
			glVertex2f(0, 0);
			glTexCoord2f(0.2f, 0);
			glVertex2f(0, ALG_MAX_Y);
			glTexCoord2f(0.8f, 0);
			glVertex2f(ALG_MAX_X, ALG_MAX_Y);
		glEnd();
		glDisable(GL_TEXTURE_2D);
	} else {
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	}

	// draw vectors
	for (i=0, vec=vectors_draw; i<vector_draw_cnt; i++, vec++) {

		unsigned int c = vec->color;

		if (VECTREX_COLORS != c) {	// valid entry ?

			c *= 2;

			glColor3ub(
				(GLubyte) (arguments.vectorcolor[0]*c/256),
				(GLubyte) (arguments.vectorcolor[1]*c/256),
				(GLubyte) (arguments.vectorcolor[2]*c/256)
			);

			// having a glBegin/glEnd pair for every
			// line or point to draw sucks somehow =)
			if ( (vec->x0 == vec->x1) && (vec->y0 == vec->y1) ) {
				glBegin(GL_POINTS);
					glVertex2i(vec->x0, vec->y0);
				glEnd();
			} else {
				glBegin(GL_LINES);
					glVertex2i(vec->x0, vec->y0);
					glVertex2i(vec->x1, vec->y1);
				glEnd();
			}
		}			
	}

	SDL_GL_SwapBuffers( );
}


static void mainloop(void) {

	Uint32 oldTicks;
	Uint32 newTicks;

	oldTicks = SDL_GetTicks();
	while (1) {
		process_events();

		// run emulator after EMU_TIMER milliseconds
		if (!paused) {
			newTicks = SDL_GetTicks();
			if (abs(newTicks-oldTicks) > EMU_TIMER) {
				oldTicks = newTicks;
				vecx_emu ((VECTREX_MHZ / 1000) * EMU_TIMER, 0);
			}
		}
	}

	// never returns
}


static void printusage(FILE *f) {

	fprintf(f, "Usage: vecxsdl [options] [file]\n");
	fprintf(f, "Options:\n");
	fprintf(f, "  -b <file>         Load BIOS image from file\n");
	fprintf(f, "                    If the -b parameter is omitted,\n");
	fprintf(f, "                    a built-in BIOS image will be used.\n");
	fprintf(f, "  -h                Display this help\n");
	fprintf(f, "  -l <#>            Set line width (default is %d)\n", DEFAULT_LINEWIDTH);
	fprintf(f, "  -o <file>         Load overlay from file\n");
	fprintf(f, "  -t <#>            Overlay transparency (0.0 to 1.0, default is %g)\n", DEFAULT_OVERLAYTRANSPARENCY);
	fprintf(f, "  -v <######>       Vector color (hex, 6 digits, default is %02x%02x%02x)\n", DEFAULT_VECTORCOLOR_R, DEFAULT_VECTORCOLOR_G, DEFAULT_VECTORCOLOR_B);
	fprintf(f, "  -x <xsize>        Window x size (default is %d)\n", DEFAULT_XRES);
	fprintf(f, "  -y <ysize>        Window y size (default is %d)\n", DEFAULT_YRES);
}


static char *getnextarg(int *index, int argc, char *argv[]) {

	if (*index >= argc) {
		return NULL;
	} else {
		char *result = argv[*index];
		(*index)++;
		return result;
	}
}


static void parsecmdline(int argc, char *argv[],  CommandLineArgs *args) {

	int index;
	char *arg;
	int have_xres = 0;
	int have_yres = 0;

	args->cartname = NULL;
	args->biosname = NULL;
	args->xres = DEFAULT_XRES;
	args->yres = DEFAULT_YRES;
	args->linewidth = DEFAULT_LINEWIDTH;
	args->overlaytransparency = DEFAULT_OVERLAYTRANSPARENCY;
	args->vectorcolor[0] = DEFAULT_VECTORCOLOR_R;
	args->vectorcolor[1] = DEFAULT_VECTORCOLOR_G;
	args->vectorcolor[2] = DEFAULT_VECTORCOLOR_B;

	// scan for -h first
	index = 0;
	while (arg = getnextarg(&index, argc, argv)) {
		if ( 0 == strcmp(arg, "-h") ) {
			printusage(stderr);
			quit(0);
		}
	}

	// parse other arguments
	index = 1;
	while (arg = getnextarg(&index, argc, argv)) {

		// -b
		if ( 0 == strcmp(arg, "-b") ) {
			arg = getnextarg(&index, argc, argv);
			if (!arg) {
				printusage(stderr);
				fprintf(stderr, "\nError : No filename given for -b.\n");
				quit(1);
			} else {
				args->biosname = arg;
			}
		}
		// -l
		else if ( 0 == strcmp(arg, "-l") ) {
			arg = getnextarg(&index, argc, argv);
			if (!arg) {
				printusage(stderr);
				fprintf(stderr, "\nError : No line width given for -l.\n");
				quit(1);
			} else {
				args->linewidth = (float) atof(arg);
				if (args->linewidth < 0) {
					printusage(stderr);
					fprintf(stderr, "\nError : Line width must be positive.\n");
					quit(1);
				}
			}
		}
		// -o
		else if ( 0 == strcmp(arg, "-o") ) {
			arg = getnextarg(&index, argc, argv);
			if (!arg) {
				printusage(stderr);
				fprintf(stderr, "\nError : no filename given for -o.\n");
				quit(1);
			} else {
				args->overlayname = arg;
			}
		}
		// -t
		else if( 0 == strcmp(arg, "-t") ) {
			arg = getnextarg(&index, argc, argv);
			if (!arg) {
				printusage(stderr);
				fprintf(stderr, "\nError : no transparency given for -t.\n");
				quit(1);
			} else {
				float v = (float) atof(arg);
				if ( (v < 0) || (v > 1) ) {
					printusage(stderr);
					fprintf(stderr, "\nError : overlay transparency must be in the range [0.0,1.0].\n");
					quit(1);
				} else {
					args->overlaytransparency = v;
				}
			}
		}
		// -v
		else if ( 0 == strcmp(arg, "-v") ) {
			arg = getnextarg(&index, argc, argv);
			if (!arg) {
				printusage(stderr);
				fprintf(stderr, "\nError : no color given for -v.\n");
				quit(1);
			} else {
				unsigned long v;
				char *c;
				v = strtoul(arg, &c, 16);
				if ( (strlen(arg) != 6) || (*c != 0) ) {
					printusage(stderr);
					fprintf(stderr, "\nError : invalid format for vector color.\n");
					quit(1);
				} else {
					args->vectorcolor[0] = (unsigned char) ((v >> 16) & 255);
					args->vectorcolor[1] = (unsigned char) ((v >> 8) & 255);
					args->vectorcolor[2] = (unsigned char) (v & 255);
				}
			}
		}
		// -x
		else if ( 0 == strcmp(arg, "-x") ) {
			arg = getnextarg(&index, argc, argv);
			if (!arg) {
				printusage(stderr);
				fprintf(stderr, "\nError : no window width given for -x.\n");
				quit(1);
			} else {
				args->xres = atoi(arg);
				have_xres = 1;
				if (args->xres < 0) {
					printusage(stderr);
					fprintf(stderr, "\nError : window width must be positive.\n");
					quit(1);
				}
			}
		}
		// -y
		else if ( 0 == strcmp(arg, "-y") ) {
			arg = getnextarg(&index, argc, argv);
			if (!arg) {
				printusage(stderr);
				fprintf(stderr, "\nError : no window height given for -y.\n");
				quit(1);
			} else {
				args->yres = atoi(arg);
				have_yres = 1;
				if (args->yres < 0) {
					printusage(stderr);
					fprintf(stderr, "\nError : window height must be positive.\n");
					quit(1);
				}
			}
		}
		else {
			args->cartname = arg;
		}
	}

	// if only x or only y given, calculate the other,
	// so that the window gets a sane aspect ratio.
	if ( (have_xres) && (!have_yres) ) {
		args->yres = args->xres*DEFAULT_YRES/DEFAULT_XRES;
	}
	else if ( (!have_xres) && (have_yres) ) {
		args->xres = args->yres*DEFAULT_XRES/DEFAULT_YRES;
	}
}


static void loadbios(const char *filename) {

	FILE *f;

	f = fopen(filename, "rb");
	if (!f) {
		fprintf(stderr, "Can't open bios image (%s).\n", filename);
		quit(1);
	}

	if (sizeof(rom) != fread(rom, 1, sizeof(rom), f)) {
		fprintf(
			stderr,
			"%s is not a valid Vectrex BIOS.\n"
			"It's smaller than %d bytes.\n",
			filename, sizeof(rom)
		);
		fclose(f);
		quit(1);
	}

	fclose(f);
}


static void loadcart(const char *filename) {

	FILE *f;
	unsigned int filesize;

	f = fopen(filename, "rb");
	if (!f) {
		fprintf(stderr, "Can't open cartridge image (%s).\n", filename);
		quit(1);
	}

	fseek(f, 0, SEEK_END);
	filesize = ftell(f);
	fseek(f, 0, SEEK_SET);

	if (filesize > sizeof(cart)) {
		fprintf(
			stderr,
			"%s is not a valid Vectrex cartridge.\n"
			"It's larger that %d bytes.\n",
			filename, sizeof(cart)
		);
		fclose(f);
		quit(1);
	}

	if (filesize != fread(cart, 1, filesize, f)) {
		fprintf(stderr, "Error while reading %s.\n", filename);
		fclose(f);
		quit(1);
	}

	fclose(f);
}


// load overlay and set it as current texture
static void loadoverlay(unsigned char *filename) {

	ILuint image;
	GLuint texture;

	image = iluGenImage();
	ilBindImage(image);
	if (!ilLoadImage(filename)) {
		fprintf(stderr, "Can't load overlay (%s).\n", filename);
		quit(1);
	}

	glGenTextures(1, &texture);
	glBindTexture(GL_TEXTURE_2D, texture);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);

	ilutGLBindTexImage();
}

// sound mixer callback
static void fillsoundbuffer(void *userdata, Uint8 *stream, int len) {
    // PS2 AY to SPU conversion:
    // SPU freq = (0x1000 * 213) / divisor

	// AY regs:
	// 0, 1 divisor channel A (12-bit)
	// 2, 3 divisor channel B
	// 4, 5 divisor channel C
	// 6    noise divisor (5-bit)
	// 7    mixer (|x|x|nC|nB|nA|tC|tB|tA)
	// 8	volume A
	// 9   volume B
	// 10   volume C
	static unsigned int noisepos = 0;
    int i;
    int divisor;

	float step[3];
	float noisestep;
	float flip[3];
	Uint8 val[3];
	Uint8 lastval;

    AY_tone_enable[0] = snd_regs[7] & 0x01;
    AY_tone_enable[1] = snd_regs[7] & 0x02;
    AY_tone_enable[2] = snd_regs[7] & 0x04;

    AY_noise_enable[0] = snd_regs[7] & 0x08;
    AY_noise_enable[1] = snd_regs[7] & 0x10;
    AY_noise_enable[2] = snd_regs[7] & 0x20;

    // calc noise freq
    divisor = (snd_regs[6] & 0x1F) << 4;
    if(divisor == 0) divisor = 256;
    
    AY_noisefreq = (440 * 213) / divisor;

    // calc tone freq and vols
    for(i=0; i<3; i++) {
        //divisor = snd_regs[i*2] + snd_regs[i*2+1] * 256;
        divisor = snd_regs[i*2] | (snd_regs[i*2+1] << 8);
        if(divisor == 0) divisor = 4095;

        //AY_spufreq[i] = (440 * 213) / divisor;
		AY_spufreq[i] = divisor;

        AY_vol[i] = (snd_regs[8+i] & 0x0F) << 2; //<< 9;

    }

	step[0] = 441.0f*(float)AY_spufreq[0]/(float)22050;
	step[1] = 441.0f*(float)AY_spufreq[1]/(float)22050;
	step[2] = 441.0f*(float)AY_spufreq[2]/(float)22050;
	//step[0] = 660.0f*(float)AY_spufreq[0]/(float)22050;
	//step[1] = 660.0f*(float)AY_spufreq[1]/(float)22050;
	//step[2] = 660.0f*(float)AY_spufreq[2]/(float)22050;
	noisestep = (441.0f * AY_noisefreq) / (float)22050;
	//noisestep = (660.0f * AY_noisefreq) / (float)22050;
	flip[0] = step[0];
	flip[1] = step[1];
	flip[2] = step[2];
	val[0] = AY_vol[0];
	val[1] = AY_vol[1];
	val[2] = AY_vol[2];

/* JH - REFERENCE CODE FROM VECXPS2
	    // update tone voices
    for(i=0; i<3; i++) {
//        spu_remote(1,spuSetCore,1,0,0,0,0,0);
        voice_att.mask = SPU_VOICE_PITCH | SPU_VOICE_VOL_LEFT | SPU_VOICE_VOL_RIGHT;
        voice_att.voice = SPU_VOICE_X(i);
        voice_att.pitch = spufreq[i];
        voice_att.vol.left = voice_att.vol.right = 0;
        if( !tone_enable[i] ) 
            voice_att.vol.left = voice_att.vol.right = vol[i];
        spu_remote(1,spuSetVoiceAttr,(u32)&voice_att,sizeof(struct spu_voice_attr),0,0,0,0);
    }


    // update noise voices
    for(i=0; i<3; i++) {
        voice_att.mask = SPU_VOICE_PITCH | SPU_VOICE_VOL_LEFT | SPU_VOICE_VOL_RIGHT;
        voice_att.voice = SPU_VOICE_X(i+3);
        voice_att.pitch = noisefreq;
        voice_att.vol.left = voice_att.vol.right = 0;
        if( !noise_enable[i] ) 
            voice_att.vol.left = voice_att.vol.right = vol[i];
        spu_remote(1,spuSetVoiceAttr,(u32)&voice_att,sizeof(struct spu_voice_attr),0,0,0,0);
    }
*/
	// fill buffer
	lastval = 0;
	for(i=0; i<len; i++)
	{
		//stream[i] = usedSpec->silence;
		stream[i] = 0;

		// do tones
		if(!AY_tone_enable[0] && AY_spufreq[0] < 4095)
			stream[i] += val[0];
		if(!AY_tone_enable[1] && AY_spufreq[1] < 4095)
			stream[i] += val[1];
		if(!AY_tone_enable[2] && AY_spufreq[1] < 4095)
			stream[i] += val[2];

		if(i>(int)flip[0]) {
			if(val[0] == AY_vol[0]) val[0] = 0;
			else val[0] = AY_vol[0];
			flip[0] = flip[0] + step[0];
		}
		if(i>(int)flip[1]) {
			if(val[1] == AY_vol[1]) val[1] = 0;
			else val[1] = AY_vol[1];
			flip[1] = flip[1] + step[1];
		}
		if(i>(int)flip[2]) {
			if(val[2] == AY_vol[2]) val[2] = 0;
			else val[2] = AY_vol[2];
			flip[2] = flip[2] + step[2];
		}

		// do noise
		if(!AY_noise_enable[0])
			stream[i] += (AY_vol[0] * wnoise[noisepos] >> 9);
		if(!AY_noise_enable[1])
			stream[i] += (AY_vol[1] * wnoise[noisepos] >> 9);
		if(!AY_noise_enable[2])
			stream[i] += (AY_vol[2] * wnoise[noisepos] >> 9);

		noisepos += (int)noisestep;
		if(noisepos > wnoise_size)
			noisepos -= wnoise_size;

		// average last 2 samples
		stream[i] = (stream[i] + lastval) >> 1;				
		lastval = stream[i];
	}

	pWave = stream;

}


int main(int argc, char* argv[]) {	

	memcpy(rom, bios, sizeof(rom));
	memset(cart, 0, sizeof(cart));

	parsecmdline(argc, argv, &arguments);

	printf("Initializing SDL\n");
	initsdl(&arguments);
	SDL_WM_SetCaption("vecxsdl", NULL);	

	printf("Initializing DevIL\n");
	ilInit();
	iluInit();
	ilutInit();
	ilutRenderer(ILUT_OPENGL);

	if (arguments.biosname) {
		loadbios(arguments.biosname);
	}

	if (arguments.cartname) {
		loadcart(arguments.cartname);
	}

	if (arguments.overlayname) {
		printf("Loading overlay (this may take a while)\n");
		loadoverlay(arguments.overlayname);
	}
	

	// set up audio buffering
	reqSpec.freq = 22050;						// Audio frequency in samples per second
	reqSpec.format = AUDIO_U8;					// Audio data format
	reqSpec.channels = 1;						// Number of channels: 1 mono, 2 stereo
	reqSpec.samples = 441;						// Audio buffer size in samples
	reqSpec.callback = fillsoundbuffer;			// Callback function for filling the audio buffer
	reqSpec.userdata = NULL;
	usedSpec = &givenSpec;
	/* Open the audio device */
	if ( SDL_OpenAudio(&reqSpec, usedSpec) < 0 ){
	  fprintf(stderr, "Couldn't open audio: %s\n", SDL_GetError());
	  exit(-1);
	}

	if(usedSpec == NULL)
		usedSpec = &reqSpec;

	// Start playing audio
	SDL_PauseAudio(0);

	printf("Done\n");
	vecx_reset();
	paused = 0;
	mainloop();

	// never reached
	return 0;
}
