#ifndef __OSINT_H
#define __OSINT_H

void osint_render(void);

#endif
