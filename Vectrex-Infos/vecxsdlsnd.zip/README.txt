Introduction
------------

vecxsdl is an SDL/OpenGL version of Valavan Manohararajah's
vecx vectrex emulator, created by Thomas Mathys.

There are several reasons why I created vecxsdl:

    -   vecx has the habit of rendering on top
        of other windows. vecxsdl doesn't do that.
    -   vecx doesn't support overlays. vecxsdl does.
    -   I became tired of vecx's "rom.dat not found"
        error message, so I linked the vectrex BIOS
        into vecxsdl.

Since vecxsdl uses SDL and OpenGL it should also be very
easy to port to other systems.



How do I get this beast to run ?
--------------------------------

If you start vecxsdl without any parameters it will
run Mine Storm, just like a real vectrex when
no cart is inserted.

To play another game, specify its name on the command
line, like this:

	vecxsdl bedlam.gam



Command line parameters
-----------------------

-b <file>       Load BIOS image from file.
                vecxsdl has an integrated BIOS image,
                but if you'd like to use a modified BIOS
                (for instance one that doesn't show
                that boring startup screen), use the -b
                parameter.

-h              Displays a help screen.

-l <#>          Set line width. The default line width
                is 1. Other values can slow down vecxsdl
                considerably (depends on your graphics card).
                
-o <file>       Load overlay from file. You can use
                the overlays from DVE.
                If you don't specify an overlay to load,
                the background will be black and
                only the vectors are drawn.
                Many different file formats are supported.
                bmp, gif, jpg, pcx, png and tga are
                just a few of them.             

-t <#>          Overlay transparency (actually intensity).
                Must be in the range [0.0, 1.0].
                Default is 0.5.
                
-v <######>     Vector color as hexadecimal number with
                6 digits (rrggbb). Default is ffffff (white).
                
-x <#>          Window width (default is 330 pixel)

-y <#>          Window height (default is 410 pixel)

Usually you'll only specify one of the -x/-y parameters.
The other one is then calculated from the given one,
so that the aspect ratio of the window is that of a
vectrex display.



Keys during emulation
---------------------

a,s,d,f         Buttons 1,2,3,4 of a vectrex controller.

Cursor keys     Joystick

ESC             Exit emulator

Backspace       Reset emulator (cold boot only)

p               Pause/continue


---

vecxsdl
Hiernach habe ich lange suchen m�ssen.. Es war nur noch in einem website Archive zu finden..
Dabei ist das eine echte Weiterentwicklung! Es kann sog. Overlays darstellen!
Es nutzt SDL , opengl und DevIL Bibliotheken. OpenGL ist bei M$ schon dabei. Die beiden anderen Biliotheken mu� man sich 
zus�tzlich herunterladen. 
Das Archive enth�lt auch Oberlay Bitmaps und Spiele-ROM's.

Es hatte mich doch einige M�he gekostet, dies unter mingw und w2k zu
compilieren. Die Fehlermeldung bei Versuch �ber Makefile zu compilieren, war 'undefined reference to WinMain@0'. Dies 
konnte ich mit einer Batchdatei zum kompilieren umgehen:

path=c:\mingw\bin
gcc -o vecxsdl vecx.c osint.c e6809.c -lmingw32 -lSDLmain -lSDL -lopengl32 -lglu32 -lDevIL -lILU -lILUT
strip vecxsdl.exe

Die DevIL Bibliotheken mu�te ich erst noch nach folgender Anleitung umwandelt:

First download DevIL for windows here http://openil.sourceforge.net/download.php.
Unpack it somewhere waiting for the next step. Before the next step you need mingw-utils.
That can be downloaded here http://sourceforge.net/project/showfiles.php?group_id=2435&release_id=115457
(under MinGW Utilities tree, file named mingw-utils.tar.gz).

Unpack mingw-utils somewhere and copy everything under bin folder to your mingw's bind directory.
(In dev-cpp: C:\Dev-cpp\bin).

Then copy the lib files (for example DevIL.lib) to mingw's bin directory. Then open command line and
cd to e.g. C:\Dev-cpp\bin and do the next command: "reimp DevIL.lib". Do this to all .lib files and
after that you have the .a files in your bin directory (for example libdevil.a). Then copy the .a files to
your compiler's lib directory.

Das Programm 'reimp.exe' war aber bei mir schon vorhanden.. deshalb konnte ich gleich loslegen.. Super Tipp!!

---

Put sound emulation in from code of James Higgs - see osint.c:
//
// This is a port of the vectrex emulator "vecx", by Valavan Manohararajah.
// Portions of this code copyright James Higgs 2005/2007.
// These portions are:
// 1. Ay38910 PSG (audio) emulation wave-buffering code.
// I, Peter Sieg used this sound emulation code from James Higgs in vecxsdl. 2007-12-06
//
